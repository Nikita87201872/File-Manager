﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic.FileIO;


namespace КУРСОВАЯ_2._0
{
    public partial class Form1 : Form
    {
        private string _filePath = @"D:\";
        private bool _isFile;
        private string _currentlySelectedItemName = "";
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle; // Фиксированная рамка
            this.MaximizeBox = false; // Отключение кнопки максимизации
            this.SizeGripStyle = SizeGripStyle.Hide; // Скрытие размерного элемента
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = _filePath;
            LoadFilesAndDerictories();
            // Subscribe to the AfterLabelEdit event
            listView1.AfterLabelEdit += listView1_AfterLabelEdit;
            // Set LabelEdit property to true
            listView1.LabelEdit = true;
        }

        public void LoadFilesAndDerictories()
        {
            DirectoryInfo fileList;
            string tempFilePath;
            FileAttributes fileAttr;
            try
            {
                if (_isFile)
                {
                    tempFilePath = _filePath + "\\" + _currentlySelectedItemName;
                    FileInfo fileDetails = new FileInfo(tempFilePath);
                    label2.Text = fileDetails.Name;
                    label4.Text = fileDetails.Extension;
                    fileAttr = File.GetAttributes(tempFilePath);
                    Process.Start(tempFilePath);
                }
                else
                {
                    fileAttr = File.GetAttributes(_filePath);
                }

                if ((fileAttr & FileAttributes.Directory) == FileAttributes.Directory)
                {
                    fileList = new DirectoryInfo(_filePath);
                    FileInfo[] files = fileList.GetFiles();
                    DirectoryInfo[] dirs = fileList.GetDirectories();
                    string fileExtension;

                    listView1.Items.Clear();

                    foreach (FileInfo file in files)
                    {
                        fileExtension = file.Extension.ToUpper();
                        switch (fileExtension)
                        {
                            case ".MP3":
                            case ".MP2":
                                listView1.Items.Add(file.Name, 4);
                                break;
                            case ".EXE":
                            case ".COM":
                                listView1.Items.Add(file.Name, 2);
                                break;
                            case ".MP4":
                            case ".AVI":
                            case ".MKV":
                                listView1.Items.Add(file.Name, 3);
                                break;
                            case ".PDF":
                                listView1.Items.Add(file.Name, 5);
                                break;
                            case ".DOC":
                            case ".DOCX":
                                listView1.Items.Add(file.Name, 7);
                                break;
                            case ".PNG":
                                listView1.Items.Add(file.Name, 9);
                                break;
                            case ".JPG":
                            case ".JPEG":
                                listView1.Items.Add(file.Name, 8);
                                break;
                            case ".TXT":
                                listView1.Items.Add(file.Name, 6);
                                break;
                            case ".RAR":
                                listView1.Items.Add(file.Name, 12);
                                break;
                            case ".ZIP":
                                listView1.Items.Add(file.Name, 0);
                                break;
                            case ".PPTX":
                                listView1.Items.Add(file.Name, 11);
                                break;

                            default:
                                listView1.Items.Add(file.Name, 1);
                                break;
                        }
                    }

                    foreach (DirectoryInfo dir in dirs)
                    {
                        listView1.Items.Add(dir.Name, 10);
                    }
                }
                else
                {
                    label2.Text = this._currentlySelectedItemName;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show($@"Error: {e.Message}", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listView1_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            _currentlySelectedItemName = e.Item.Text;

            FileAttributes fileAttr = File.GetAttributes(_filePath + "\\" + _currentlySelectedItemName);

            if ((fileAttr & FileAttributes.Directory) == FileAttributes.Directory)
            {
                _isFile = false;
                //textBox1.Text = filePath + "\\" + currentlySelectedItemName;
            }
            else
            {
                _isFile = true;
            }
        }

        public void LoadButtonAction()
        {
            RemoveBackSlash();
            _filePath = textBox1.Text;
            LoadFilesAndDerictories();
            _isFile = false;
        }

        public void RemoveBackSlash()
        {
            string path = textBox1.Text;
            if (path.LastIndexOf("\\", StringComparison.Ordinal) == path.Length - 1)
            {
                textBox1.Text = path.Substring(0, path.Length - 1);
            }
        }

        public void GoBack()
        {
            try
            {
                RemoveBackSlash();
                string path = textBox1.Text;
                path = path.Substring(0, path.LastIndexOf("\\", StringComparison.Ordinal));
                this._isFile = false;
                textBox1.Text = path;
                RemoveBackSlash();
            }
            catch (Exception e)
            {
                MessageBox.Show($@"Error: {e.Message}", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (_isFile)
            {
                LoadButtonAction();
            }
            else
            {
                textBox1.Text = _filePath + @"\" + _currentlySelectedItemName;
                LoadButtonAction();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GoBack();
            LoadButtonAction();
        }

        private void listView1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                Point mousePos = listView1.PointToClient(Control.MousePosition);
                ListViewItem clickedItem = listView1.GetItemAt(mousePos.X, mousePos.Y);

                if (clickedItem != null)
                {
                    // Клик по элементу в ListView
                    contextMenuStrip1.Show(listView1, mousePos);
                }
                else
                {
                    // Клик по пустой области в ListView
                    contextMenuStrip2.Show(listView1, mousePos);
                }
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_isFile)
            {
                LoadButtonAction();
            }
            else
            {
                textBox1.Text = _filePath + @"\" + _currentlySelectedItemName;
                LoadButtonAction();
            }
        }

        private ListViewItem _cutItem;
        private string _sourceCutItemPath;

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                _cutItem = listView1.SelectedItems[0];
                // По желанию, обновите интерфейс для указания, что элемент "вырезан".
                _cutItem.ForeColor = Color.Gray;
                // Снять выделение в listView1
                listView1.SelectedItems.Clear();
                _sourceCutItemPath = Path.Combine(_filePath, _cutItem.Text);
            }
        }

        private ListViewItem _copyItem;
        private string _sourceCopyItemPath;

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                _copyItem = listView1.SelectedItems[0];
                _sourceCopyItemPath = Path.Combine(_filePath, _copyItem.Text);
            }
        }

        private void renameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = listView1.SelectedItems[0];

                // Begin the edit operation on the selected item
                selectedItem.BeginEdit();
            }
        }
        
        private void listView1_AfterLabelEdit(object sender, LabelEditEventArgs e)
        {
            if (e.Label != null)
            {
                string newName = e.Label;

                // Assuming that the path is the same as the current directory
                string currentPath = Path.Combine(_filePath, _currentlySelectedItemName);
                string newPath = Path.Combine(_filePath, newName);
                
                try
                {
                    // Move the directory
                    Directory.Move(currentPath, newPath);

                    // Update the ListView with the new name
                    listView1.Items[e.Item].Text = newName;

                    // Update currentlySelectedItemName to the new name
                    _currentlySelectedItemName = newName;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($@"Error: {ex.Message}", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void propertiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                string selectedItemPath = Path.Combine(_filePath, _currentlySelectedItemName);

                // Check if the selected item is a file or directory
                if (File.Exists(selectedItemPath))
                {
                    // If it's a file, show file properties
                    FileInfo fileInfo = new FileInfo(selectedItemPath);
                    ShowFileProperties(fileInfo);
                }
                else if (Directory.Exists(selectedItemPath))
                {
                    // If it's a directory, show directory properties
                    DirectoryInfo dirInfo = new DirectoryInfo(selectedItemPath);
                    ShowDirectoryProperties(dirInfo);
                }
            }
            catch (Exception ex)
            {
                // Handle any errors while retrieving or displaying properties
                MessageBox.Show($@"Error displaying properties: {ex.Message}", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void ShowFileProperties(FileInfo fileInfo)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"File Name: {fileInfo.Name}");
            sb.AppendLine($"Full Path: {fileInfo.FullName}");
            sb.AppendLine($"Size: {fileInfo.Length} bytes");
            sb.AppendLine($"Created: {fileInfo.CreationTime}");
            sb.AppendLine($"Last Modified: {fileInfo.LastWriteTime}");

            // Add any other file-specific properties as needed

            MessageBox.Show(sb.ToString(), @"File Properties", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ShowDirectoryProperties(DirectoryInfo dirInfo)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Directory Name: {dirInfo.Name}");
            sb.AppendLine($"Full Path: {dirInfo.FullName}");
            sb.AppendLine($"Created: {dirInfo.CreationTime}");
            sb.AppendLine($"Last Modified: {dirInfo.LastWriteTime}");

            // Add any other directory-specific properties as needed

            MessageBox.Show(sb.ToString(), @"Directory Properties", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                string selectedItemPath = Path.Combine(_filePath, _currentlySelectedItemName);

                // Check if the selected item is a file or directory
                if (File.Exists(selectedItemPath))
                {
                    // If it's a file, delete the file and move it to the Recycle Bin
                    FileSystem.DeleteFile(selectedItemPath, UIOption.OnlyErrorDialogs, RecycleOption.SendToRecycleBin);
                }
                else if (Directory.Exists(selectedItemPath))
                {
                    // If it's a directory, delete the directory and move it to the Recycle Bin
                    FileSystem.DeleteDirectory(selectedItemPath, UIOption.OnlyErrorDialogs, RecycleOption.SendToRecycleBin);
                }

                // Refresh the file explorer after deletion
                LoadButtonAction();
            }
            catch (Exception ex)
            {
                // Handle any errors during the deletion process
                MessageBox.Show($@"Error deleting: {ex.Message}", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            LoadButtonAction();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (_cutItem != null || _copyItem != null)
                {
                    if (File.Exists(_sourceCopyItemPath) || File.Exists(_sourceCutItemPath))
                    {
                        if (_cutItem != null)
                        {
                            string destinationPath = Path.Combine(_filePath, _cutItem.Text);
                            File.Move(_sourceCutItemPath, destinationPath);
                            _cutItem = null;
                        }
                        else if (_copyItem != null)
                        {
                            string destinationPath = Path.Combine(_filePath, _copyItem.Text);
                            File.Copy(_sourceCopyItemPath, destinationPath);
                        }
                    }
                    else if (Directory.Exists(_sourceCopyItemPath) || Directory.Exists(_sourceCutItemPath))
                    {
                        if (_cutItem != null)
                        {
                            string destinationPath = Path.Combine(_filePath, _cutItem.Text);
                            Directory.Move(_sourceCutItemPath, destinationPath);
                            _cutItem = null;
                        }
                        else if (_copyItem != null)
                        {
                            string destinationPath = Path.Combine(_filePath, _copyItem.Text);
                            CopyDirectory(_sourceCopyItemPath, destinationPath);
                        }
                    }
                    LoadButtonAction();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($@"Error pasting: {ex.Message}", @"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Function to recursively copy a directory and its contents
        private void CopyDirectory(string sourcePath, string destinationPath)
        {
            DirectoryInfo sourceDirectory = new DirectoryInfo(sourcePath);
            DirectoryInfo destinationDirectory = new DirectoryInfo(destinationPath);

            // Create the destination directory if it doesn't exist
            if (!destinationDirectory.Exists)
            {
                destinationDirectory.Create();
            }

            // Copy files
            foreach (FileInfo file in sourceDirectory.GetFiles())
            {
                string filePath = Path.Combine(destinationPath, file.Name);
                file.CopyTo(filePath, true);
            }

            // Copy subdirectories
            foreach (DirectoryInfo subDirectory in sourceDirectory.GetDirectories())
            {
                string subDirectoryPath = Path.Combine(destinationPath, subDirectory.Name);
                CopyDirectory(subDirectory.FullName, subDirectoryPath);
            }
        }
        private void textDocumentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            string baseFileName = "Text Document.txt";
            string newFile = Path.Combine(_filePath, baseFileName);

            // Проверяем существует ли файл с таким именем
            int counter = 1;
            while (File.Exists(newFile))
            {
                // Генерируем новое имя файла с добавлением счетчика
                string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(baseFileName);
                string fileExtension = Path.GetExtension(baseFileName);
                string newFileName = $"{fileNameWithoutExtension}({counter}){fileExtension}";

                newFile = Path.Combine(_filePath, newFileName);
                counter++;
            }
            File.Create(newFile);
            LoadButtonAction();
            
            // Find the ListViewItem corresponding to the new file
            ListViewItem newItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Text.Equals(Path.GetFileName(newFile), StringComparison.OrdinalIgnoreCase))
                {
                    newItem = item;
                    break;
                }
            }

            // If the ListViewItem is found, simulate a click event to start renaming
            if (newItem != null)
            {
                newItem.Selected = true;
                newItem.BeginEdit();
            }
        }

        private void direrctoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string baseFileName = "New Directory";
            string newDirectory = Path.Combine(_filePath, baseFileName);

            // Проверяем существует ли файл с таким именем
            int counter = 1;
            while (Directory.Exists(newDirectory))
            {
                // Генерируем новое имя файла с добавлением счетчика
                string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(baseFileName);
                string fileExtension = Path.GetExtension(baseFileName);
                string newFileName = $"{fileNameWithoutExtension}({counter}){fileExtension}";

                newDirectory = Path.Combine(_filePath, newFileName);
                counter++;
            }
            Directory.CreateDirectory(newDirectory);
            LoadButtonAction();
            
            // Find the ListViewItem corresponding to the new file
            ListViewItem newItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Text.Equals(Path.GetFileName(newDirectory), StringComparison.OrdinalIgnoreCase))
                {
                    newItem = item;
                    break;
                }
            }

            // If the ListViewItem is found, simulate a click event to start renaming
            if (newItem != null)
            {
                newItem.Selected = true;
                newItem.BeginEdit();
            }
        }

        private void documentMicrosoftWordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string baseFileName = "Word Document.doc";
            string newFile = Path.Combine(_filePath, baseFileName);

            // Проверяем существует ли файл с таким именем
            int counter = 1;
            while (File.Exists(newFile))
            {
                // Генерируем новое имя файла с добавлением счетчика
                string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(baseFileName);
                string fileExtension = Path.GetExtension(baseFileName);
                string newFileName = $"{fileNameWithoutExtension}({counter}){fileExtension}";

                newFile = Path.Combine(_filePath, newFileName);
                counter++;
            }
            File.Create(newFile);
            LoadButtonAction();
            
            // Find the ListViewItem corresponding to the new file
            ListViewItem newItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Text.Equals(Path.GetFileName(newFile), StringComparison.OrdinalIgnoreCase))
                {
                    newItem = item;
                    break;
                }
            }

            // If the ListViewItem is found, simulate a click event to start renaming
            if (newItem != null)
            {
                newItem.Selected = true;
                newItem.BeginEdit();
            }
        }
        
        private void presentationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string baseFileName = "PowerPoint Presentation.pptx";
            string newFile = Path.Combine(_filePath, baseFileName);

            // Проверяем существует ли файл с таким именем
            int counter = 1;
            while (File.Exists(newFile))
            {
                // Генерируем новое имя файла с добавлением счетчика
                string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(baseFileName);
                string fileExtension = Path.GetExtension(baseFileName);
                string newFileName = $"{fileNameWithoutExtension}({counter}){fileExtension}";

                newFile = Path.Combine(_filePath, newFileName);
                counter++;
            }
            File.Create(newFile);
            LoadButtonAction();
            
            // Find the ListViewItem corresponding to the new file
            ListViewItem newItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Text.Equals(Path.GetFileName(newFile), StringComparison.OrdinalIgnoreCase))
                {
                    newItem = item;
                    break;
                }
            }

            // If the ListViewItem is found, simulate a click event to start renaming
            if (newItem != null)
            {
                newItem.Selected = true;
                newItem.BeginEdit();
            }
        }
        
        private void archiveWinRarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string baseFileName = "Archive WinRar.rar";
            string newFile = Path.Combine(_filePath, baseFileName);

            // Проверяем существует ли файл с таким именем
            int counter = 1;
            while (File.Exists(newFile))
            {
                // Генерируем новое имя файла с добавлением счетчика
                string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(baseFileName);
                string fileExtension = Path.GetExtension(baseFileName);
                string newFileName = $"{fileNameWithoutExtension}({counter}){fileExtension}";

                newFile = Path.Combine(_filePath, newFileName);
                counter++;
            }
            File.Create(newFile);
            LoadButtonAction();
            
            // Find the ListViewItem corresponding to the new file
            ListViewItem newItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Text.Equals(Path.GetFileName(newFile), StringComparison.OrdinalIgnoreCase))
                {
                    newItem = item;
                    break;
                }
            }

            // If the ListViewItem is found, simulate a click event to start renaming
            if (newItem != null)
            {
                newItem.Selected = true;
                newItem.BeginEdit();
            }
        }
        
        private void compresedDocumentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string baseFileName = "Compresed Document.zip";
            string newFile = Path.Combine(_filePath, baseFileName);

            // Проверяем существует ли файл с таким именем
            int counter = 1;
            while (File.Exists(newFile))
            {
                // Генерируем новое имя файла с добавлением счетчика
                string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(baseFileName);
                string fileExtension = Path.GetExtension(baseFileName);
                string newFileName = $"{fileNameWithoutExtension}({counter}){fileExtension}";

                newFile = Path.Combine(_filePath, newFileName);
                counter++;
            }
            File.Create(newFile);
            LoadButtonAction();
            
            // Find the ListViewItem corresponding to the new file
            ListViewItem newItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Text.Equals(Path.GetFileName(newFile), StringComparison.OrdinalIgnoreCase))
                {
                    newItem = item;
                    break;
                }
            }

            // If the ListViewItem is found, simulate a click event to start renaming
            if (newItem != null)
            {
                newItem.Selected = true;
                newItem.BeginEdit();
            }
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadButtonAction();
        }

        private void Download_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Text = @"C:\Users\sukus\Downloads";
            LoadButtonAction();
        }

        private void Documents_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Text = @"C:\Users\sukus\Documents";
            LoadButtonAction();
        }

        private void Images_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Text = @"C:\Users\sukus\Pictures";
            LoadButtonAction();
        }

        private void Music_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Text = @"C:\Users\sukus\Music";
            LoadButtonAction();
        }

        private void Video_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Text = @"C:\Users\sukus\Videos";
            LoadButtonAction();
        }

        private void Desktop_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Text = @"C:\Users\sukus\Desktop";
            LoadButtonAction();
        }

        private void DiskC_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Text = @"C:\\";
            LoadButtonAction();
        }

        private void DickD_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Text = @"D:\\";
            LoadButtonAction();
        }
    }
}