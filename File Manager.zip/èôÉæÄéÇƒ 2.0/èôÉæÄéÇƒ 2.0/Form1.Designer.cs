﻿namespace КУРСОВАЯ_2._0
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.renameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.propertiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textDocumentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.direrctoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.documentMicrosoftWordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.presentationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.archiveWinRarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.compresedDocumentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Download = new System.Windows.Forms.Button();
            this.Documents = new System.Windows.Forms.Button();
            this.Images = new System.Windows.Forms.Button();
            this.Music = new System.Windows.Forms.Button();
            this.Video = new System.Windows.Forms.Button();
            this.Desktop = new System.Windows.Forms.Button();
            this.DiskC = new System.Windows.Forms.Button();
            this.DickD = new System.Windows.Forms.Button();
            this.contextMenuStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(167, 39);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(248, 39);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(922, 26);
            this.textBox1.TabIndex = 1;
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.LargeImageList = this.imageList1;
            this.listView1.Location = new System.Drawing.Point(169, 77);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1001, 476);
            this.listView1.SmallImageList = this.imageList1;
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.AfterLabelEdit += new System.Windows.Forms.LabelEditEventHandler(this.listView1_AfterLabelEdit);
            this.listView1.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.listView1_ItemSelectionChanged);
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClick);
            this.listView1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDown);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "zip.png");
            this.imageList1.Images.SetKeyName(1, "unknown.png");
            this.imageList1.Images.SetKeyName(2, "exe.png");
            this.imageList1.Images.SetKeyName(3, "mp4.png");
            this.imageList1.Images.SetKeyName(4, "mp3.png");
            this.imageList1.Images.SetKeyName(5, "pgf.png");
            this.imageList1.Images.SetKeyName(6, "txt.png");
            this.imageList1.Images.SetKeyName(7, "doc.png");
            this.imageList1.Images.SetKeyName(8, "jpg.png");
            this.imageList1.Images.SetKeyName(9, "png.png");
            this.imageList1.Images.SetKeyName(10, "folderyellow_92963.png");
            this.imageList1.Images.SetKeyName(11, "pptx.png");
            this.imageList1.Images.SetKeyName(12, "rar.png");
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(169, 556);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 3;
            this.label1.Text = "File Name";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(275, 556);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 4;
            this.label2.Text = "--";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(955, 556);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 5;
            this.label3.Text = "File Type";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(1071, 556);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 23);
            this.label4.TabIndex = 6;
            this.label4.Text = "--";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.openToolStripMenuItem, this.cutToolStripMenuItem, this.copyToolStripMenuItem, this.renameToolStripMenuItem, this.propertiesToolStripMenuItem, this.deleteToolStripMenuItem });
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(165, 184);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.cutToolStripMenuItem.Text = "Cut";
            this.cutToolStripMenuItem.Click += new System.EventHandler(this.cutToolStripMenuItem_Click);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.copyToolStripMenuItem.Text = "Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // renameToolStripMenuItem
            // 
            this.renameToolStripMenuItem.Name = "renameToolStripMenuItem";
            this.renameToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.renameToolStripMenuItem.Text = "Rename";
            this.renameToolStripMenuItem.Click += new System.EventHandler(this.renameToolStripMenuItem_Click);
            // 
            // propertiesToolStripMenuItem
            // 
            this.propertiesToolStripMenuItem.Name = "propertiesToolStripMenuItem";
            this.propertiesToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.propertiesToolStripMenuItem.Text = "Properties";
            this.propertiesToolStripMenuItem.Click += new System.EventHandler(this.propertiesToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(164, 30);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.pasteToolStripMenuItem, this.createToolStripMenuItem, this.refreshToolStripMenuItem });
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(143, 94);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(142, 30);
            this.pasteToolStripMenuItem.Text = "Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
            // 
            // createToolStripMenuItem
            // 
            this.createToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.textDocumentToolStripMenuItem, this.direrctoryToolStripMenuItem, this.documentMicrosoftWordToolStripMenuItem, this.presentationToolStripMenuItem, this.archiveWinRarToolStripMenuItem, this.compresedDocumentToolStripMenuItem });
            this.createToolStripMenuItem.Name = "createToolStripMenuItem";
            this.createToolStripMenuItem.Size = new System.Drawing.Size(142, 30);
            this.createToolStripMenuItem.Text = "Create";
            // 
            // textDocumentToolStripMenuItem
            // 
            this.textDocumentToolStripMenuItem.Name = "textDocumentToolStripMenuItem";
            this.textDocumentToolStripMenuItem.Size = new System.Drawing.Size(356, 30);
            this.textDocumentToolStripMenuItem.Text = "Text Document";
            this.textDocumentToolStripMenuItem.Click += new System.EventHandler(this.textDocumentToolStripMenuItem_Click);
            // 
            // direrctoryToolStripMenuItem
            // 
            this.direrctoryToolStripMenuItem.Name = "direrctoryToolStripMenuItem";
            this.direrctoryToolStripMenuItem.Size = new System.Drawing.Size(356, 30);
            this.direrctoryToolStripMenuItem.Text = "Direrctory";
            this.direrctoryToolStripMenuItem.Click += new System.EventHandler(this.direrctoryToolStripMenuItem_Click);
            // 
            // documentMicrosoftWordToolStripMenuItem
            // 
            this.documentMicrosoftWordToolStripMenuItem.Name = "documentMicrosoftWordToolStripMenuItem";
            this.documentMicrosoftWordToolStripMenuItem.Size = new System.Drawing.Size(356, 30);
            this.documentMicrosoftWordToolStripMenuItem.Text = "Document Microsoft Word";
            this.documentMicrosoftWordToolStripMenuItem.Click += new System.EventHandler(this.documentMicrosoftWordToolStripMenuItem_Click);
            // 
            // presentationToolStripMenuItem
            // 
            this.presentationToolStripMenuItem.Name = "presentationToolStripMenuItem";
            this.presentationToolStripMenuItem.Size = new System.Drawing.Size(356, 30);
            this.presentationToolStripMenuItem.Text = "Presentation Microsoft PowerPoint";
            this.presentationToolStripMenuItem.Click += new System.EventHandler(this.presentationToolStripMenuItem_Click);
            // 
            // archiveWinRarToolStripMenuItem
            // 
            this.archiveWinRarToolStripMenuItem.Name = "archiveWinRarToolStripMenuItem";
            this.archiveWinRarToolStripMenuItem.Size = new System.Drawing.Size(356, 30);
            this.archiveWinRarToolStripMenuItem.Text = "Archive WinRar";
            this.archiveWinRarToolStripMenuItem.Click += new System.EventHandler(this.archiveWinRarToolStripMenuItem_Click);
            // 
            // compresedDocumentToolStripMenuItem
            // 
            this.compresedDocumentToolStripMenuItem.Name = "compresedDocumentToolStripMenuItem";
            this.compresedDocumentToolStripMenuItem.Size = new System.Drawing.Size(356, 30);
            this.compresedDocumentToolStripMenuItem.Text = "Compresed Document";
            this.compresedDocumentToolStripMenuItem.Click += new System.EventHandler(this.compresedDocumentToolStripMenuItem_Click);
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(142, 30);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // Download
            // 
            this.Download.Location = new System.Drawing.Point(12, 77);
            this.Download.Name = "Download";
            this.Download.Size = new System.Drawing.Size(151, 37);
            this.Download.TabIndex = 8;
            this.Download.Text = "Download";
            this.Download.UseVisualStyleBackColor = true;
            this.Download.Click += new System.EventHandler(this.Download_Click);
            // 
            // Documents
            // 
            this.Documents.Location = new System.Drawing.Point(12, 120);
            this.Documents.Name = "Documents";
            this.Documents.Size = new System.Drawing.Size(151, 37);
            this.Documents.TabIndex = 9;
            this.Documents.Text = "Documents";
            this.Documents.UseVisualStyleBackColor = true;
            this.Documents.Click += new System.EventHandler(this.Documents_Click);
            // 
            // Images
            // 
            this.Images.Location = new System.Drawing.Point(12, 163);
            this.Images.Name = "Images";
            this.Images.Size = new System.Drawing.Size(151, 37);
            this.Images.TabIndex = 10;
            this.Images.Text = "Images";
            this.Images.UseVisualStyleBackColor = true;
            this.Images.Click += new System.EventHandler(this.Images_Click);
            // 
            // Music
            // 
            this.Music.Location = new System.Drawing.Point(12, 206);
            this.Music.Name = "Music";
            this.Music.Size = new System.Drawing.Size(151, 37);
            this.Music.TabIndex = 11;
            this.Music.Text = "Music";
            this.Music.UseVisualStyleBackColor = true;
            this.Music.Click += new System.EventHandler(this.Music_Click);
            // 
            // Video
            // 
            this.Video.Location = new System.Drawing.Point(12, 249);
            this.Video.Name = "Video";
            this.Video.Size = new System.Drawing.Size(151, 37);
            this.Video.TabIndex = 12;
            this.Video.Text = "Video";
            this.Video.UseVisualStyleBackColor = true;
            this.Video.Click += new System.EventHandler(this.Video_Click);
            // 
            // Desktop
            // 
            this.Desktop.Location = new System.Drawing.Point(12, 292);
            this.Desktop.Name = "Desktop";
            this.Desktop.Size = new System.Drawing.Size(151, 37);
            this.Desktop.TabIndex = 13;
            this.Desktop.Text = "Desktop";
            this.Desktop.UseVisualStyleBackColor = true;
            this.Desktop.Click += new System.EventHandler(this.Desktop_Click);
            // 
            // DiskC
            // 
            this.DiskC.Location = new System.Drawing.Point(12, 335);
            this.DiskC.Name = "DiskC";
            this.DiskC.Size = new System.Drawing.Size(151, 37);
            this.DiskC.TabIndex = 14;
            this.DiskC.Text = "Disk C:";
            this.DiskC.UseVisualStyleBackColor = true;
            this.DiskC.Click += new System.EventHandler(this.DiskC_Click);
            // 
            // DickD
            // 
            this.DickD.Location = new System.Drawing.Point(12, 378);
            this.DickD.Name = "DickD";
            this.DickD.Size = new System.Drawing.Size(151, 37);
            this.DickD.TabIndex = 15;
            this.DickD.Text = "Disk D:";
            this.DickD.UseVisualStyleBackColor = true;
            this.DickD.Click += new System.EventHandler(this.DickD_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1187, 615);
            this.Controls.Add(this.DickD);
            this.Controls.Add(this.DiskC);
            this.Controls.Add(this.Desktop);
            this.Controls.Add(this.Video);
            this.Controls.Add(this.Music);
            this.Controls.Add(this.Images);
            this.Controls.Add(this.Documents);
            this.Controls.Add(this.Download);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "File Manager";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Button DiskC;
        private System.Windows.Forms.Button DickD;

        private System.Windows.Forms.Button Desktop;

        private System.Windows.Forms.Button Documents;
        private System.Windows.Forms.Button Images;
        private System.Windows.Forms.Button Music;
        private System.Windows.Forms.Button Video;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;

        private System.Windows.Forms.Button Download;

        private System.Windows.Forms.ToolStripMenuItem compresedDocumentToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem archiveWinRarToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem presentationToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem direrctoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem documentMicrosoftWordToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem textDocumentToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem createToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem propertiesToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem renameToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;

        private System.Windows.Forms.ImageList imageList1;

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;

        private System.Windows.Forms.ListView listView1;

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;

        #endregion
    }
}